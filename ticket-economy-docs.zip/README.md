# 文旅消费券积分平台

面向游客、商户、景区与运营方的「消费票据兑换 + 盲盒发券 + 商户核销 + 积分成长」平台。

本仓库将 ChatGPT 设计讨论整理为可立项、可研发落地的工程资产，覆盖：

- 产品需求（PRD）
- 业务状态机
- 系统架构
- 数据库 DDL
- OpenAPI 接口
- Redis / MQ 设计
- 风控方案
- 部署与排期

## 目录结构

```text
ticket-economy/
├── README.md
├── docs/
│   ├── 01-PRD.md
│   ├── 02-业务状态机.md
│   ├── 03-系统架构.md
│   ├── 04-页面与角色.md
│   ├── 05-Redis与MQ设计.md
│   ├── 06-风控方案.md
│   ├── 07-权限模型.md
│   ├── 08-部署方案.md
│   ├── 09-研发排期.md
│   └── 10-交付清单.md
├── sql/
│   ├── 00-init.sql
│   ├── 01-user.sql
│   ├── 02-merchant.sql
│   ├── 03-ticket.sql
│   ├── 04-coupon-blindbox.sql
│   ├── 05-points-checkin.sql
│   ├── 06-risk-admin.sql
│   └── 99-seed.sql
├── openapi/
│   └── openapi.yaml
├── apps/                 # 预留：消费者/商户小程序、管理后台
├── services/             # 预留：微服务骨架
├── infrastructure/       # 预留：中间件配置
├── deploy/               # 部署说明与 K8s 示例
└── scripts/
    └── package-docs.sh
```

## 产品一句话

用户上传消费票据 → AI 审核 → 盲盒抽消费券 → 商户核销 → 积分发放与兑换，形成本地消费闭环。

## 角色

| 角色 | 端 | 核心能力 |
| --- | --- | --- |
| 消费者 | 微信小程序 | 上传票据、抽盲盒、用券、打卡、积分 |
| 商户 | 商户小程序 | 门店注册、扫码验券、核销统计 |
| 运营/审核 | 管理后台 | 发券规则、积分规则、人工审票、统计 |
| 系统 | AI / 风控服务 | OCR、多模态验真、防重复、风险评分 |

## MVP 范围（建议 3 个月）

必须做：

1. 上传票据
2. AI 自动审核 + 人工复核
3. 盲盒抽奖发券
4. 商户扫码核销
5. 积分流水与兑换
6. 后台统计

暂缓：

- 地铁 / 滴滴 / 电影票正式对接
- Beacon / 视频核验
- AI 导游与城市画像
- 数据大屏 2.0

## 推荐技术栈

| 层 | 选型 |
| --- | --- |
| 消费者/商户端 | 微信小程序（Taro + Vue3 / uni-app） |
| 管理后台 | Vue3 + Element Plus |
| API | NestJS 或 Spring Boot |
| 数据库 | MySQL 8 |
| 缓存 | Redis |
| 消息 | RabbitMQ |
| 对象存储 | OSS / COS / MinIO |
| AI | OCR + 多模态大模型 |
| 部署 | Docker + Nginx（一期），后期 K8s |

## 核心业务链路

```text
上传票据 → OCR → AI 风控评分
   ├─ 通过 → 盲盒 → 发券 → 核销 → 积分
   ├─ 人工审核 → 通过/拒绝
   └─ 拒绝 → 结束
```

## 快速阅读顺序

1. [docs/01-PRD.md](docs/01-PRD.md)
2. [docs/02-业务状态机.md](docs/02-业务状态机.md)
3. [docs/03-系统架构.md](docs/03-系统架构.md)
4. [sql/00-init.sql](sql/00-init.sql)
5. [openapi/openapi.yaml](openapi/openapi.yaml)
6. [docs/06-风控方案.md](docs/06-风控方案.md)

## 打包文档

```bash
bash scripts/package-docs.sh
```

会在仓库根目录生成 `ticket-economy-docs.zip`。

## 说明

- 当前仓库是「设计与工程资产包」，可直接用于立项评审与研发开工。
- SQL 与 OpenAPI 按 MVP + 可扩展结构编写，后续第三方券平台通过适配层接入。
- 真实开发前请根据城市运营方、景区/地铁对接能力裁剪一期范围。
